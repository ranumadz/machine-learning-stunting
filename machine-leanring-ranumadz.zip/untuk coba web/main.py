import streamlit as st
import pandas as pd
from sklearn.preprocessing import MinMaxScaler, LabelEncoder
from sklearn.linear_model import LinearRegression
from sklearn.naive_bayes import GaussianNB
from sklearn.neural_network import MLPClassifier
import pickle
from streamlit_echarts import st_pyecharts
from pyecharts.charts import Line, Scatter
from pyecharts import options as opts

# Load the trained models and scaler
model_lr = pickle.load(open('model_lr.sav', 'rb'))
model_nb = pickle.load(open('model_nb.sav', 'rb'))
model_nn = pickle.load(open('model_nn.sav', 'rb'))
scaler = pickle.load(open('scaler.sav', 'rb'))

# Load the encoders
encoder_bb_u = pickle.load(open('encoder_bb_u.pkl', 'rb'))
encoder_tb_u = pickle.load(open('encoder_tb_u.pkl', 'rb'))
encoder_jk = pickle.load(open('encoder_jk.pkl', 'rb'))

# Function to normalize new data
def normalize_data(new_data, scaler):
    return scaler.transform(new_data)

# Function to encode categorical data using loaded encoders
def encode_categorical(data, column, encoder):
    try:
        data[column] = encoder.transform(data[column].astype(str))
    except Exception as e:
        st.error(f"Error encoding column {column}: {e}")
        raise
    return data

# Function to preprocess and predict
def preprocess_and_predict(data):
    # Encode categorical columns using the pre-fitted encoders
    try:
        data = encode_categorical(data, 'BB/U', encoder_bb_u)
        data = encode_categorical(data, 'TB/U', encoder_tb_u)
        data = encode_categorical(data, 'JK', encoder_jk)
    except Exception as e:
        st.error(f"Error processing data for prediction: {e}")
        return None

    # Ensure the dataset has the correct number of features
    required_columns = ["Berat", "Tinggi", "BB/U", "TB/U", "JK"]
    data = data[required_columns]  # Select required columns
    data_scaled = normalize_data(data, scaler)  # Use the same scaler as training

    return data_scaled

# Function to create the stunting line chart using pyecharts
def create_stunting_line_chart():
    data_tahun = ["2018", "2019", "2020", "2021", "2022"]
    data_stunting = [150, 130, 120, 140, 135]  # Example data
    line = (
        Line()
        .add_xaxis(data_tahun)
        .add_yaxis("Jumlah Kasus Stunting", data_stunting)
        .set_global_opts(
            title_opts=opts.TitleOpts(title="Perkembangan Kasus Stunting di Wilayah Cikupa"),
            yaxis_opts=opts.AxisOpts(name="Jumlah Kasus"),
            xaxis_opts=opts.AxisOpts(name="Tahun")
        )
    )
    return line

def create_stunting_scatter_chart():
    data_tahun = ["2018", "2019", "2020", "2021", "2022"]
    data_stunting = [150, 130, 120, 140, 135]  # Example data
    
    # Identifikasi titik tertinggi
    max_value = max(data_stunting)
    max_index = data_stunting.index(max_value)
    
    scatter = (
        Scatter()
        .add_xaxis(data_tahun)
        .add_yaxis(
            "Jumlah Kasus Stunting",
            data_stunting,
            symbol_size=10,  # Ukuran simbol normal
            label_opts=opts.LabelOpts(is_show=False)  # Hide labels
        )
        .add_yaxis(
            "Titik Tertinggi",
            [None] * len(data_tahun),  # Titik selain tertinggi akan kosong
            symbol="circle",
            symbol_size=20,  # Ukuran lingkaran yang lebih besar untuk titik tertinggi
            itemstyle_opts=opts.ItemStyleOpts(color="red", border_color="black", border_width=2),  # Warna merah untuk titik tertinggi
            label_opts=opts.LabelOpts(is_show=True, position="top", formatter="Tertinggi")  # Menampilkan label
        )
        .set_global_opts(
            title_opts=opts.TitleOpts(title="Kasus Stunting di Wilayah Cikupa (Scatter)"),
            yaxis_opts=opts.AxisOpts(name="Jumlah Kasus"),
            xaxis_opts=opts.AxisOpts(name="Tahun")
        )
    )
    
    # Tambahkan lingkaran merah untuk titik tertinggi
    scatter.add_yaxis(
        "Titik Tertinggi",
        [data_stunting[i] if i == max_index else None for i in range(len(data_stunting))],  # Titik tertinggi
        symbol="circle",
        symbol_size=20,  # Ukuran lingkaran yang lebih besar
        itemstyle_opts=opts.ItemStyleOpts(color="red", border_color="black", border_width=2),  # Warna merah dan border hitam
        label_opts=opts.LabelOpts(is_show=True, position="top", formatter="Tertinggi")  # Menampilkan label
    )
    
    return scatter

st.title("Puskesmas Cikupa Online Stunting Apps")

# Updated menu
menu = ["Dashboard", "Predict", "Stunting dari Tahun ke Tahun"]
choice = st.sidebar.selectbox("Menu", menu)

if choice == "Dashboard":
    st.subheader("Dashboard")
    st.write("""
    Selamat datang di Puskesmas Online Stunting Cikupa.
    Aplikasi ini dirancang untuk membantu dalam pemantauan dan prediksi kasus stunting di wilayah Cikupa, 
    memberikan layanan terbaik untuk masyarakat. Dengan alat ini, kita dapat lebih proaktif dalam mencegah dan menangani kasus stunting.
    Mari bersama kita wujudkan generasi yang lebih sehat dan kuat!
    """)
    
    # Display health-related news or information
    st.subheader("Informasi Kesehatan Anak")
    st.write("""
    - **Pentingnya Gizi Seimbang:** Pastikan anak mendapatkan asupan gizi yang cukup dari berbagai sumber makanan, termasuk sayuran, buah-buahan, protein, dan karbohidrat.
    - **Pemantauan Berkala:** Lakukan pemeriksaan kesehatan secara rutin untuk memantau perkembangan anak dan mendeteksi masalah kesehatan lebih awal.
    - **Aktivitas Fisik:** Dorong anak untuk aktif bergerak dan berolahraga secara teratur untuk menjaga kesehatan fisik dan mental mereka.
    """)
    


elif choice == "Predict":
    st.subheader("Predict")
    st.write("Masukkan data untuk melakukan prediksi atau unggah datasheet:")

    # Input manual
    berat = st.text_input("Berat (kg)")
    tinggi = st.text_input("Tinggi (cm)")
    bb_u = st.text_input("BB/U")
    tb_u = st.text_input("TB/U")
    jk = st.selectbox("Jenis Kelamin", options=[0, 1], format_func=lambda x: "Laki-laki" if x==0 else "Perempuan")

    # Input datasheet
    st.write("Atau unggah datasheet (file Excel):")
    uploaded_file = st.file_uploader("Pilih file Excel", type=["xlsx"])

    if st.button("Predict"):
        if uploaded_file is not None:
            try:
                datasheet = pd.read_excel(uploaded_file)
                st.write("Data yang diunggah:")
                st.write(datasheet.head())

                # Pastikan kolom yang diperlukan ada di dalam datasheet
                required_columns = ["Berat", "Tinggi", "BB/U", "TB/U", "JK"]
                if all(col in datasheet.columns for col in required_columns):
                    try:
                        datasheet_scaled = preprocess_and_predict(datasheet)
                        if datasheet_scaled is not None:
                            # Prediksi dengan masing-masing model
                            predictions_lr = model_lr.predict(datasheet_scaled)
                            predictions_nb = model_nb.predict(datasheet_scaled)
                            predictions_nn = model_nn.predict(datasheet_scaled)

                            # Definisikan kategori berdasarkan BB/TB
                            categories = {
                                0: 'Gizi Baik',
                                1: 'Gizi Buruk',
                                2: 'Gizi Kurang',
                                3: 'Gizi Lebih',
                                4: 'Obesitas',
                                5: 'Risiko Gizi Lebih'
                            }

                            # Tambahkan hasil prediksi ke datasheet
                            datasheet["Prediksi_LR"] = [categories[int(pred)] for pred in predictions_lr]
                            datasheet["Prediksi_NB"] = [categories[int(pred)] for pred in predictions_nb]
                            datasheet["Prediksi_NN"] = [categories[int(pred)] for pred in predictions_nn]

                            st.subheader("Hasil Prediksi dari Datasheet:")
                            st.write(datasheet)
                    except ValueError as e:
                        st.error(f"Terjadi kesalahan dalam memproses datasheet: {e}")
            except Exception as e:
                st.error(f"Terjadi kesalahan dalam mengunggah file: {e}")

        elif berat and tinggi and bb_u and tb_u:
            try:
                # Konversi input teks ke float
                berat = float(berat.replace(',', '.'))
                tinggi = float(tinggi.replace(',', '.'))
                bb_u = float(bb_u.replace(',', '.'))
                tb_u = float(tb_u.replace(',', '.'))
                jk = int(jk)

                new_data = pd.DataFrame([[berat, tinggi, bb_u, tb_u, jk]], columns=["Berat", "Tinggi", "BB/U", "TB/U", "JK"])
                new_data_scaled = preprocess_and_predict(new_data)
                if new_data_scaled is not None:
                    # Prediksi dengan masing-masing model
                    prediction_lr = model_lr.predict(new_data_scaled)[0]
                    prediction_nb = model_nb.predict(new_data_scaled)[0]
                    prediction_nn = model_nn.predict(new_data_scaled)[0]

                    # Definisikan kategori berdasarkan BB/TB
                    categories = {
                        0: 'Gizi Baik',
                        1: 'Gizi Buruk',
                        2: 'Gizi Kurang',
                        3: 'Gizi Lebih',
                        4: 'Obesitas',
                        5: 'Risiko Gizi Lebih'
                    }

                    # Tampilkan hasil prediksi dengan label yang jelas
                    st.subheader("Hasil Prediksi:")
                    st.write(f"Linear Regression: {categories[int(prediction_lr)]}")
                    st.write(f"Naive Bayes: {categories[int(prediction_nb)]}")
                    st.write(f"Neural Network: {categories[int(prediction_nn)]}")

            except ValueError as e:
                st.error(f"Terjadi kesalahan: {e}")

elif choice == "Stunting dari Tahun ke Tahun":
    st.subheader("Stunting dari Tahun ke Tahun")
    st.write("Grafik tren stunting dari tahun ke tahun di wilayah Cikupa.")

    # Display line chart
    line_chart = create_stunting_line_chart()
    st_pyecharts(line_chart, height="400px")

    # Display scatter chart
    scatter_chart = create_stunting_scatter_chart()
    st_pyecharts(scatter_chart, height="400px")












# import streamlit as st
# import pandas as pd
# import numpy as np
# from sklearn.preprocessing import MinMaxScaler
# import pickle

# # Load the trained models
# model_lr = pickle.load(open('model_lr.sav', 'rb'))
# model_nb = pickle.load(open('model_nb.sav', 'rb'))
# model_nn = pickle.load(open('model_nn.sav', 'rb'))

# # Function to normalize new data
# def normalize_data(new_data):
#     scaler = MinMaxScaler()
#     return scaler.fit_transform(new_data)

# # Streamlit app
# st.title("Aplikasi Prediksi Stunting")

# menu = ["Dashboard", "Predict"]
# choice = st.sidebar.selectbox("Menu", menu)

# if choice == "Dashboard":
#     st.subheader("Dashboard")
#     st.write("Selamat datang di aplikasi prediksi stunting.")

# elif choice == "Predict":
#     st.subheader("Predict")
#     st.write("Masukkan data untuk melakukan prediksi:")

#     Berat = st.text_input('Input nilai Berat', key='berat_input')
#     Tinggi = st.text_input('Input nilai Tinggi', key='tinggi_input')
#     BB_U = st.text_input('Input nilai BB/U', key='bb_u_input')
#     TB_U = st.text_input('Input nilai TB/U', key='tb_u_input')
#     JK = st.text_input('Input Jenis kelamin (0 = Laki-laki, 1 = Perempuan)', key='JK_input')

#     predict_pred_lr = ''
#     predict_pred_nb = ''
#     predict_pred_nn = ''

#     if st.button('Test prediksi stunting'):
#         if Berat and Tinggi and BB_U and TB_U and JK:
#             # Create new data as a list of lists
#             new_data = [[float(Berat), float(Tinggi), float(BB_U), float(TB_U), float(JK)]]
#             new_data_scaled = normalize_data(new_data)

#             # Predict with each model
#             if model_lr.coef_.shape[0] == 6:  # Check if the number of features matches
#                 predict_pred_lr = model_lr.predict(new_data_scaled)

#             if model_nb.n_features_ == 6:  # Example check for Naive Bayes (if applicable)
#                 predict_pred_nb = model_nb.predict(new_data_scaled)

#             if model_nn.input_shape[1] == 6:  # Example check for Neural Network (if applicable)
#                 predict_pred_nn = model_nn.predict(new_data_scaled)

#     st.write("Hasil Prediksi:")
#     st.write(f"Prediksi dengan Linear Regression: {predict_pred_lr}")
#     st.write(f"Prediksi dengan Naive Bayes: {predict_pred_nb}")
#     st.write(f"Prediksi dengan Neural Network: {predict_pred_nn}")
