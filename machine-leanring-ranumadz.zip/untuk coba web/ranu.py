import streamlit as st
import pandas as pd
from sklearn.preprocessing import MinMaxScaler, LabelEncoder
from sklearn.linear_model import LinearRegression
from sklearn.naive_bayes import GaussianNB
from sklearn.neural_network import MLPClassifier
import pickle

model_lr= pickle.load(open('model_lr.sav','rb'))
model_nb= pickle.load(open('model_nb.sav','rb'))
model_nn= pickle.load(open('model_nn.sav','rb'))

def normalize_data(new_data, scaler)
    return scaler.tranform(new_data)

def encode_categorical(data, colum):
    encoder = LabelEncoder()
    data[colum] = encoder.fit_transform(data[colum].astype(str))
    return data

def preprocess_and_predict(data):
    data = encode_catagorical(data,BB/U)