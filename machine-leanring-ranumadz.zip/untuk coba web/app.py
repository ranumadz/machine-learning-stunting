from flask import Flask, render_template, request, redirect, url_for
import pandas as pd
from sklearn.preprocessing import LabelEncoder, MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import GaussianNB
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix
from imblearn.over_sampling import SMOTE
from imblearn.under_sampling import RandomUnderSampler
import os

app = Flask(__name__)

# Load and preprocess data
data = pd.read_excel('data-stunting.xlsx')
features = data[['Berat', 'Tinggi', 'BB/U', 'TB/U', 'ZS BB/U', 'ZS TB/U', 'ZS BB/TB', 'JK', 'BB/TB']]

label_encoders = {}
for column in ['JK', 'BB/U', 'TB/U', 'BB/TB']:
    label_encoders[column] = LabelEncoder()
    features[column] = label_encoders[column].fit_transform(features[column])

features = features.dropna()
X = features.drop(columns=['BB/TB'])
y = features['BB/TB']

scaler = MinMaxScaler()
X = scaler.fit_transform(X)

smote = SMOTE(sampling_strategy={1:1000, 2:1000, 3:1000, 4:1000, 5:1000}, random_state=42)
X_resampled, y_resampled = smote.fit_resample(X, y)

undersampler = RandomUnderSampler(random_state=42)
X_resampled, y_resampled = undersampler.fit_resample(X_resampled, y_resampled)

X_train, X_test, y_train, y_test = train_test_split(X_resampled, y_resampled, test_size=0.2, random_state=42)

models = {
    "Logistic Regression": LogisticRegression(),
    "Naive Bayes": GaussianNB(),
    "Neural Network": MLPClassifier(random_state=42)
}

model_results = {}

for model_name, model in models.items():
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    model_results[model_name] = {
        "accuracy": accuracy_score(y_test, y_pred),
        "report": classification_report(y_test, y_pred, output_dict=True),
        "confusion_matrix": confusion_matrix(y_test, y_pred)
    }

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/result', methods=['POST'])
def result():
    model_name = request.form['model']
    result = model_results[model_name]
    return render_template('result.html', model_name=model_name, result=result)

@app.route('/upload_data', methods=['POST'])
def upload_data():
    if 'file' not in request.files:
        return redirect(url_for('index'))
    
    file = request.files['file']
    if file.filename == '':
        return redirect(url_for('index'))

    # Save uploaded file
    filepath = os.path.join('uploads', file.filename)
    file.save(filepath)

    # Process uploaded file (similar to your previous code)
    try:
        datasheet = pd.read_excel(filepath)
        datasheet = datasheet[['Berat', 'Tinggi', 'BB/U', 'TB/U', 'JK']]
        datasheet = datasheet.dropna()

        for column in ['JK', 'BB/U', 'TB/U']:
            datasheet[column] = label_encoders[column].transform(datasheet[column])

        datasheet_scaled = scaler.transform(datasheet)

        predictions = {}
        for model_name, model in models.items():
            pred = model.predict(datasheet_scaled)
            predictions[model_name] = [categories[int(p)] for p in pred]

        datasheet['Prediction_LR'] = predictions['Logistic Regression']
        datasheet['Prediction_NB'] = predictions['Naive Bayes']
        datasheet['Prediction_NN'] = predictions['Neural Network']

        return render_template('prediction_result.html', datasheet=datasheet.to_html(classes='table table-striped'))

    except Exception as e:
        error_message = f"Error processing file: {e}"
        return render_template('error.html', error_message=error_message)

if __name__ == '__main__':
    app.run(debug=True)
